// ============================================================
// ATLAS SOLUTIONS - JAVASCRIPT
// Controla as interações e comportamentos do site.
// ============================================================

// ------------------------------------------------------------
// 1. MENU MOBILE
// ------------------------------------------------------------
// Seleciona o botão que abre o menu e o elemento que contém
// os links da navegação.
const botaoMenu = document.querySelector('.botao-menu');
const linksNavegacao = document.querySelector('.links-navegacao');

// Ao clicar no botão, adiciona ou remove a classe "aberto".
// O CSS usa essa classe para exibir o menu em telas menores.
botaoMenu?.addEventListener('click', () => {
    const menuAberto = linksNavegacao.classList.toggle('aberto');

    // Informa aos recursos de acessibilidade se o menu está aberto.
    botaoMenu.setAttribute('aria-expanded', menuAberto);
});

// ------------------------------------------------------------
// 2. FECHAR O MENU DEPOIS DE ESCOLHER UMA SEÇÃO
// ------------------------------------------------------------
// Quando um link do menu é clicado, o menu mobile é fechado.
document.querySelectorAll('.links-navegacao a').forEach(link => {
    link.addEventListener('click', () => {
        linksNavegacao.classList.remove('aberto');
    });
});

// ------------------------------------------------------------
// 3. LINK ATIVO CONFORME A SEÇÃO VISÍVEL
// ------------------------------------------------------------
// Obtém todas as seções que possuem um ID e todos os links
// do menu que apontam para essas seções.
const secoes = [...document.querySelectorAll('main section[id]')];
const linksMenu = [...document.querySelectorAll('.links-navegacao a')];

// Descobre qual seção está sendo visualizada durante o scroll.
const definirLinkAtivo = () => {
    const posicaoAtual = window.scrollY + 140;
    let secaoAtual = secoes[0]?.id;

    secoes.forEach(secao => {
        if (posicaoAtual >= secao.offsetTop) {
            secaoAtual = secao.id;
        }
    });

    // Deixa ativo somente o link correspondente à seção atual.
    linksMenu.forEach(link => {
        link.classList.toggle(
            'ativo',
            link.getAttribute('href') === `#${secaoAtual}`
        );
    });
};

// Atualiza o menu enquanto o usuário rola a página.
window.addEventListener('scroll', definirLinkAtivo, { passive: true });

// Executa uma vez ao carregar a página.
definirLinkAtivo();

// ------------------------------------------------------------
// 4. ANIMAÇÕES AO ENTRAR NA TELA
// ------------------------------------------------------------
// IntersectionObserver identifica quando um elemento aparece
// na tela. Isso permite ativar a animação somente nesse momento.
const observador = new IntersectionObserver(
    entradas => {
        entradas.forEach(entrada => {
            if (entrada.isIntersecting) {
                // A classe "visivel" faz o elemento aparecer.
                entrada.target.classList.add('visivel');

                // Depois da primeira animação, não precisamos observar
                // o elemento novamente.
                observador.unobserve(entrada.target);
            }
        });
    },
    {
        // A animação começa quando 12% do elemento estiver visível.
        threshold: 0.12
    }
);

// Observa todos os elementos que possuem a classe "aparecer".
document.querySelectorAll('.aparecer').forEach(elemento => {
    observador.observe(elemento);
});

// ------------------------------------------------------------
// 5. ANO AUTOMÁTICO DO RODAPÉ
// ------------------------------------------------------------
// Insere automaticamente o ano atual no rodapé.
document.getElementById('ano').textContent = new Date().getFullYear();

// ------------------------------------------------------------
// 6. FORMULÁRIO DE CONTATO
// ------------------------------------------------------------
// Impede o recarregamento da página e mostra uma mensagem.
// Para envio real, este ponto deverá ser conectado ao backend/API.
document.getElementById('formularioContato')?.addEventListener(
    'submit',
    evento => {
        evento.preventDefault();

        const formulario = evento.currentTarget;
        const aviso = document.getElementById('avisoFormulario');

        aviso.textContent =
            'Mensagem preparada! Conecte este formulário ao seu backend ou serviço de e-mail para receber os contatos.';

        // Limpa os campos depois do envio.
        formulario.reset();
    }
);
