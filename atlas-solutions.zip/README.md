# ATLAS Solutions

Site institucional com HTML, CSS e JavaScript organizados para estudo.

- Classes e IDs em português.
- HTML comentado por seção.
- CSS em estrutura tradicional e comentado.
- JavaScript em português, dividido por funcionalidades e comentado.
- Identidade visual preservada.

Abra `index.html` para visualizar.
